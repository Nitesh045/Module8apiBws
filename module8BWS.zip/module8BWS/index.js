let Name = document.getElementById("name");
let Gender = document.getElementById("gender");
let Mass = document.getElementById("mass");
let Skin = document.getElementById("skin");
let Height = document.getElementById("height");
let btn = document.getElementById("btn");
let showMore = document.getElementById("btninfo");
let info = document.getElementById("info");
let btninfo1 = document.getElementById("btninfo1");
showMore.style.display="none";
info.style.display="none";

btninfo1.style.display="none";
  

function getinfo(){
    fetch(`https://swapi.dev/api/people/${Math.floor(Math.random()*100)}/`)
    .then(response => response.json())
    .then(data =>{
        console.log(data);
       btn.innerText="Next";
       Name.innerHTML="Name :" + data.name;
       showMore.style.display="block";
      Gender.innerHTML="Gender :"+ data.gender;
      Mass.innerHTML="Mass :" + data.mass;
      Skin.innerHTML="Skin coulor :" + data.skin_color;
      Height.innerHTML="Mass :" + data.height;


      // gen1.style.display="none"
      
    })
    info.style.display="none";
    btninfo1.style.display="none";
   
}
function nitesh(){
    info.style.display="block";
    console.log("hii");
    showMore.style.display="none";
    btninfo1.style.display="block";
}
function nitesh1(){
    info.style.display="none";
    showMore.style.display="block";
    btninfo1.style.display="none";
}